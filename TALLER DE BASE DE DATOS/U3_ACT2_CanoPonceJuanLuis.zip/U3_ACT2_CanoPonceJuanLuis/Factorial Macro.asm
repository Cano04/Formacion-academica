org 100h

.data
  numero      dw ?      
  result      dw ?
  mensaje_res db 13, 10, "EL FACTORIAL ES: $"
  mensaje_num db "INGRESE UN NUMERO: $"

CALCULAR_FACTORIAL MACRO valor
  LOCAL operacion, fin_factorial, cero

  mov ax, valor
  cmp ax, 0
  je cero

  mov cx, ax
  mov ax, 1

operacion:
  mul cx
  loop operacion

  mov result, ax
  jmp fin_factorial

cero:
  mov result, 1

fin_factorial:
ENDM

.code

start:

  ; IMPRIMIR MENSAJE DE INGRESO
  mov ah, 09h
  mov dx, offset mensaje_num
  int 21h

  call leer_numero
  mov numero, ax

  CALCULAR_FACTORIAL numero

  mov ax, result
  out 130, ax

  mov ah, 09h
  mov dx, offset mensaje_res
  int 21h

  mov ax, result
  call mostrar_numero

  mov ah, 4Ch
  int 21h

; SUBRUTINA PARA LEER N�MERO DEL USUARIO

leer_numero:
  push bx
  push cx
  mov bx, 0      
  mov cx, 10
  
leer_digito:
  mov ah, 01h    
  int 21h
  cmp al, 13     
  je fin_lectura

  sub al, 30h    
  mov ah, 0      
  push ax        

  mov ax, bx     
  mul cx
  mov bx, ax

  pop ax         
  add bx, ax     
  jmp leer_digito

fin_lectura:
  mov ax, bx     
  pop cx
  pop bx
  ret

; SUBRUTINA PARA MOSTRAR NUMERO EN PANTALLA

mostrar_numero:
  push ax
  push bx
  push cx
  push dx
  
  mov cx, 0      
  mov bx, 10     

dividir:
  mov dx, 0      
  div bx       
  push dx        
  inc cx         
  test ax, ax    
  jnz dividir    

mostrar_digitos:
  pop dx         
  add dl, '0'    
  mov ah, 02h    
  int 21h
  loop mostrar_digitos

  pop dx
  pop cx
  pop bx
  pop ax
  ret

