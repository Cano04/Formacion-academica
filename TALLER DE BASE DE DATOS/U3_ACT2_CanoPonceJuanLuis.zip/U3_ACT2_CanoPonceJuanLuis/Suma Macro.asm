.model small
.stack 100h
.data
    buffer1 db 6 dup(0)
    buffer2 db 6 dup(0)
    resultado dw 0
    salida db 6 dup(0)
    msg1 db "Ingrese primer numero: $"
    msg2 db 13,10,"Ingrese segundo numero: $"
    msg3 db 13,10,"Resultado: $"
    msg4 db 13,10,"Presione una tecla para salir...$"

.code

sum_macro macro val1, val2, res
    mov ax, val1
    add ax, val2
    mov res, ax
endm

leer_num proc
    push cx
    push bx
    push dx
    mov si, dx
    mov cx, 0

leer_loop:
    mov ah, 01h
    int 21h
    cmp al, 13
    je fin_lectura
    cmp al, '0'
    jb leer_loop
    cmp al, '9'
    ja leer_loop
    mov [si], al
    inc si
    inc cx
    cmp cx, 5
    je fin_lectura
    jmp leer_loop

fin_lectura:
    mov byte ptr [si], 0
    mov si, dx
    xor ax, ax
    xor bx, bx

convertir_loop:
    mov bl, [si]
    cmp bl, 0
    je fin_convertir
    sub bl, '0'
    mov bh, 0        ; Zero-extend bl to bx
    push bx
    mov dx, ax
    mov ax, dx
    mov dx, 0
    mov bx, 10
    mul bx
    pop bx
    add ax, bx       ; Add digit to ax
    inc si
    jmp convertir_loop

fin_convertir:
    pop dx
    pop bx
    pop cx
    ret
leer_num endp

itoa proc
    push ax
    push bx
    push cx
    push dx
    push si
    mov si, offset salida+5
    mov byte ptr [si+1], 0  ; Null-terminate
    mov bx, 10
    cmp ax, 0
    jne itoa_loop_start
    mov byte ptr [si], '0'
    dec si
    jmp itoa_done

itoa_loop_start:
    xor dx, dx

itoa_loop:
    div bx
    add dl, '0'
    mov [si], dl
    dec si
    cmp ax, 0
    jne itoa_loop

itoa_done:
    inc si
    pop si
    pop dx
    pop cx
    pop bx
    pop ax
    ret
itoa endp

imprimir proc
    push dx
    push ax
    push si
    mov si, offset salida

imprimir_loop:
    mov al, [si]
    cmp al, 0
    je imprimir_fin
    mov ah, 02h
    mov dl, al
    int 21h
    inc si
    jmp imprimir_loop

imprimir_fin:
    pop si
    pop ax
    pop dx
    ret
imprimir endp

start:
    mov ax, @data
    mov ds, ax
    ; Stack initialization not needed in emu8086, but set SP for clarity
    mov sp, 100h

    lea dx, msg1
    mov ah, 09h
    int 21h
    lea dx, buffer1
    call leer_num
    mov bx, ax

    lea dx, msg2
    mov ah, 09h
    int 21h
    lea dx, buffer2
    call leer_num
    mov cx, ax

    sum_macro bx, cx, resultado
    mov ax, resultado

    lea dx, msg3
    mov ah, 09h
    int 21h

    call itoa
    call imprimir

    lea dx, msg4
    mov ah, 09h
    int 21h
    mov ah, 01h
    int 21h

    mov ah, 4Ch
    int 21h
end start