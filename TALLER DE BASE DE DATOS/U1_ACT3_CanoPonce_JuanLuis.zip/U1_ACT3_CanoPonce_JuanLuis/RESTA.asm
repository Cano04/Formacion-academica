include 'emu8086.inc'
.data

Suma db 2 dup(?)
Sumas proc
    printn "INGRESE EL PRIMER NUMERO:"
    call scan_num
    mov suma[0], cl
    printn ""
    printn "INGRESE EL SEGUNDO NUMERO:"
    call scan_num
    mov suma[1], cl
    printn ""
    ;; SUMA
    xor ax, ax
    add al, suma[0]
    add al, suma[1]
    printn ""
    printn "LA SUMA ES: "
    call print_num
    ;; RESTA
    xor ax, ax
    mov al, suma[0]  
    sub al, suma[1]  
    printn ""
    printn "LA RESTA ES: "
    call print_num
Sumas endp

exit:
    printn ""
    printn "+ + + PRESIONE ENTER PARA SALIR + + +"
    mov ah, 0
    int 16h
    ret

define_print_string
define_print_num
define_print_num_uns
define_scan_num

end




