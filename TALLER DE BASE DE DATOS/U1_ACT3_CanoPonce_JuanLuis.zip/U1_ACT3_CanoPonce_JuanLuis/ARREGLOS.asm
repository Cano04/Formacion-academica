ORG 100h  

MOV SI, 0        
MOV CX, 3        
MOV AX, 0        

ARRAY DB 5, 11, 6  

SUM_LOOP:
    ADD AL, [ARRAY + SI]  
    INC SI                
    LOOP SUM_LOOP         

MOV RESULT, AL  


MOV DL, AL      
MOV AH, 02h     
INT 21h        

HLT  

RESULT DB ?
  






