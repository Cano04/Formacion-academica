.MODEL SMALL
.STACK 100h  
.DATA
    msg db "HALOO FLACOW$"  
.CODE
MAIN PROC
    
    MOV AX, @DATA
    MOV DS, AX

    
    MOV DX, OFFSET msg  
    MOV AH, 09h
    INT 21h

   
    MOV AX, 4C00h
    INT 21h

MAIN ENDP
END MAIN
