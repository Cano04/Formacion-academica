ORG 100h  

    MOV AX, arreglo     
    MOV BX, arreglo+2   
    MOV CX, arreglo+4   

    ; Intercambiar AX con BX
    XCHG AX, BX
    
    ; Intercambiar BX con CX
    XCHG BX, CX

    
    INT 20h             

arreglo DW 1234h, 5678h, 9ABCh  

END



