package codigo;
import static codigo.Tokens.*;
%%
%class Lexer
%type Tokens
L=[a-zA-Z_]+
D=[0-9]+
espacio=[ ,\t,\r,\n]+
%{
    public String lexeme;
%}
%%
Vill | 
Con | 
Nad | 
Gen | 
Eje | 
Capivara |
INICIO: | 
FINAL | 
Si | 
Sino | 
Mientras | 
Para |
Hacer |
Retornar | 
Leer | 
Escribir |
Verdadero | 
Falso |
int |
if |
else |
while {lexeme=yytext(); return Reservadas;}
{espacio} {/*Ignore*/}
"//".* {/*Ignore*/}
"=" {return Igual;}
"+" {return Suma;}
"-" {return Resta;}
"*" {return Multiplicacion;}
"/" {return Division;}
{L}({L}|{D})* {lexeme=yytext(); return Identificador;}
({D}+"."+{D}+)|{D}+ {lexeme=yytext(); return Numero;}
. {return ERROR;}
